"""Governed Project Status MCP capability (platform-agnostic)."""
CAPABILITY_ID = "ahead.project-status"
__version__ = "0.1.1"  # stamped from the release manifest at artifact build time
