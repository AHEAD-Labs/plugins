"""Governed Project Status MCP capability (platform-agnostic)."""
CAPABILITY_ID = "ahead.project-status"
__version__ = "0.2.3"  # stamped from the release manifest at artifact build time
