"""Governed Incident Lookup MCP capability (local-only example)."""
CAPABILITY_ID = "ahead.incident-lookup"
__version__ = "0.1.0"  # stamped from the release manifest at artifact build time
